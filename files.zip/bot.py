"""
Aternos Minecraft Bot - Python Versiyonu
javascript-bridge (javascript2python) yerine javascript_bridge kullanır
Gereksinim: pip install javascript
"""

import time
import threading
from javascript import require, On, Once, AsyncTask, start

# ===================== AYARLAR =====================
CONFIG = {
    'host': 'SUNUCU_ADI.aternos.me',   # Aternos sunucu adresi
    'port': 25565,                       # Port
    'username': 'BotAdi',                # Bot kullanıcı adı
    'version': '1.20.1',                 # Minecraft versiyonu
    'password': 'agf9301',               # AuthMe şifresi
    'auth': 'offline',                   # 'offline' veya 'microsoft'
}
# ===================================================

mineflayer = require('mineflayer')

registered = False
logged_in = False

def create_bot():
    global registered, logged_in
    registered = False
    logged_in = False

    bot = mineflayer.createBot({
        'host': CONFIG['host'],
        'port': CONFIG['port'],
        'username': CONFIG['username'],
        'version': CONFIG['version'],
        'auth': CONFIG['auth'],
    })

    @On(bot, 'spawn')
    def on_spawn(*args):
        global registered, logged_in
        registered = False
        logged_in = False
        print('[BOT] Sunucuya bağlandı!')

    @On(bot, 'message')
    def on_message(this, json_msg, *args):
        global registered, logged_in
        message = str(json_msg)
        print(f'[SOHBET] {message}')
        msg_lower = message.lower()

        # AuthMe: Kayıtlı değil → register
        if any(keyword in msg_lower for keyword in [
            'you are not registered',
            'please register',
            'kayıtlı değilsiniz',
            'kayıt olun',
            'register to play',
            '/register'
        ]):
            if not registered:
                time.sleep(1)
                bot.chat(f'/register {CONFIG["password"]} {CONFIG["password"]}')
                print('[BOT] /register komutu gönderildi.')
                registered = True

        # AuthMe: Kayıtlı → login
        elif any(keyword in msg_lower for keyword in [
            'please login',
            'you are registered',
            'login to play',
            'giriş yapın',
            'kayıtlısınız',
            'oturum açın',
            '/login'
        ]):
            if not logged_in:
                time.sleep(1)
                bot.chat(f'/login {CONFIG["password"]}')
                print('[BOT] /login komutu gönderildi.')
                logged_in = True

        # Texture pack sorusu
        if any(keyword in msg_lower for keyword in [
            'texture', 'resource pack', 'kaynak paketi', 'texturepack'
        ]):
            print('[BOT] Texture pack sorusu algılandı.')

    @On(bot, 'resource_pack_send')
    def on_resource_pack(this, url, hash, *args):
        print(f'[BOT] Resource pack teklifi reddedildi: {url}')
        bot.acceptResourcePack(False)

    @On(bot, 'error')
    def on_error(this, err, *args):
        print(f'[HATA] {err}')

    @On(bot, 'kicked')
    def on_kicked(this, reason, *args):
        print(f'[BOT] Kicklendi: {reason}')

    @On(bot, 'end')
    def on_end(this, reason, *args):
        print(f'[BOT] Bağlantı kesildi: {reason}')
        print('[BOT] 5 saniye sonra yeniden bağlanılıyor...')
        time.sleep(5)
        create_bot()

    return bot

if __name__ == '__main__':
    print('[BOT] Başlatılıyor...')
    create_bot()
    start()
